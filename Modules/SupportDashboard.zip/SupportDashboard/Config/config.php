<?php

return [
    'name' => 'SupportDashboard',
];
