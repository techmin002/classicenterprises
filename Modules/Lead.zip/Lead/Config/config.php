<?php

return [
    'name' => 'Lead'
];
